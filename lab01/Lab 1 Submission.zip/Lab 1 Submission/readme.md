This lab is based on: https://cs.calvin.edu/courses/cs/262/kvlinden/01introduction/lab.html
